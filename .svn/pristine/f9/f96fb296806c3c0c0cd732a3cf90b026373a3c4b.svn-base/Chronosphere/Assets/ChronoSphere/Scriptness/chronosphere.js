//Set the length of a full day, measured in minutes
var daySpeed = 0.0 ;  
//Tracks what the current hour is
private var hourTrack = 0.0; 
//Track the legnth of a single hour in seconds
private var hourLength = 0.0;
//Tell the Chronosphere at which hour to begin
var hourStart = 0; 
private var latestShift = 0;

//Define the parts of the Chronosphere we will manipulate.
var sun : UnityEngine.GameObject;
var sunShifts : Shift[];
var moon : UnityEngine.GameObject;
var moonShifts : Shift[];
var nightSphere : UnityEngine.GameObject;
var nightSphereShifts : Shift[];



function Start ()
{
	initializeHour(); 
	solRotation(); 
}

private function solRotation ()
{
	
	hourLength = (daySpeed * 60) / 24; //determines the legnth in seconds of an in-game hour
	orbitSun(); // orbit the sun around the level
	InvokeRepeating("hourCount", hourLength, hourLength); //tracks the ongoing hour

}

private function initializeHour ()
{
	sun.transform.eulerAngles.x = (270 + (hourStart * 15));
	hourTrack = hourStart;
	initializeShift();

}

private function hourCount()
{
	if (hourTrack < 23)
		hourTrack = hourTrack + 1;
	else
		hourTrack = 0;
		
	updateShift();

}

private function orbitSun () 
{
	iTween.rotateBy(sun,{"x" : 1 , "y" : 0, "z" : 0, "time" : (daySpeed * 60), "transition" : "linear", "loopType" : "loop"});	
	iTween.rotateBy(nightSphere,{"x" : 1 , "y" : 0, "z" : 0, "time" : (daySpeed * 60), "transition" : "linear", "loopType" : "loop"});	
}

function updateShift()
{
	for (var i=0; i < sunShifts.length; i++)
	{
	
		if (sunShifts[i].startHour == hourTrack)
			sunShifts[i].shiftChange(hourLength);
	
	}
	
	for (var j=0; j < nightSphereShifts.length; j++)
	{
	
		if (nightSphereShifts[j].startHour == hourTrack)
			nightSphereShifts[j].shiftChange(hourLength*3);
	
	}
	
	for (var k=0; k < moonShifts.length; k++)
	{
	
		if (moonShifts[k].startHour == hourTrack)
			moonShifts[k].shiftChange(hourLength);
	
	}
	
}

function initializeShift()
{
	//iterates through the various lights and spheres to find
	//the latest shifts and initializes the objects to them
	for (var i=0; i < sunShifts.length; i++)
	{
	
		if (sunShifts[i].startHour <= hourStart){
			latestShift = i;
		}
	}
	sunShifts[latestShift].shiftChange(0.05);
	
	for (var j=0; j < nightSphereShifts.length; j++)
	{
	
		if (nightSphereShifts[j].startHour <= hourStart){
			latestShift = j;
		}
	}
	nightSphereShifts[latestShift].shiftChange(0.05);

	for (var k=0; k < moonShifts.length; k++)
	{
	
		if (moonShifts[k].startHour <= hourStart){
			latestShift = k;
		}
	}
	moonShifts[latestShift].shiftChange(0.05);

}

function Update ()
{
	
	
	
}