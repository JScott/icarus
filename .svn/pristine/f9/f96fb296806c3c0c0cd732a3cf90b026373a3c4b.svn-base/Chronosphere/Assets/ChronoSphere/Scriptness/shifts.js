class Shift
{
	/*A Shift is a period of time where certain
	settings are used. By setting up multiple 
	Shifts, you can turn off the Sun when it dips
	under the horizon, or change the color of the 
	clouds from an errie white at night to a more
	realistic dark. Make sure to create shifts in
	chronological order, or else the initialization
	may not work as expected!
	*/
	var subject : UnityEngine.GameObject;
	var targetAlpha = 0.0;
	var targetR = 0.0;
	var targetG = 0.0;
	var targetB = 0.0;
	var startHour = 0;
	var isThisALight = true;
	//var targetX = 0.0;
	//var targetY = 0.0;
	//var targetZ = 0.0;
	
	function shiftChange(hourLength)
	{
		if (isThisALight)
			iTween.lightTo(subject,{"r" : targetR, "g" : targetG, "b" : targetB, "time" : (hourLength / 2)});
		else{
			iTween.fadeTo(subject,{"alpha" : targetAlpha, "time" : (hourLength / 2)});
			iTween.colorTo(subject,{"r" : targetR, "g" : targetG, "b" : targetB, "time" : (hourLength / 2)});
			}
	}
	
}


function Update () {}